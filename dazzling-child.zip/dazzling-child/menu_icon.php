<?php
/*
* Template Name: Menu-Icon
* Template Post Type: icon
*/
?>

<img class="menu-icon" src="wp-content/themes/dazzling-child/images/tradetryon_logo.png" />
